/**
 * Supabase Client
 * 
 * This file is kept for backward compatibility.
 * New code should import from @/config/supabase instead.
 */

import { supabase } from "../../config/supabase";

export { supabase };
